0.9.2: Qt startup and desktop file model tests pass; QML session dropdown click test passes. USB verifier tested with synthetic files/devices only. No full ISO build, real PAM authentication, physical USB mount integration or full X11 drag/drop session verified in this revision. Prior regression script stops at missing host cmake, after successful window controls and Python/C tasks. Hardware testing remains necessary.

0.9.3: native X11/Openbox/picom maximize-to-bottom, workarea, dock click over application and actual transparency integration passed. Overlay policy, monochrome rendering, active underline tests passed. Full ISO boot / physical GPU not tested.

0.9.5: dock Qt startup, dimensions, contrasting backing and panel task regression passed. Gradient glass appearance, no actual backdrop blur. ISO not built or boot-tested here.
