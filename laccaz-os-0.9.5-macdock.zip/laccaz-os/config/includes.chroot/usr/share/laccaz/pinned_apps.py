import json,os,configparser
from pathlib import Path
from PySide6.QtCore import Qt,QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QScrollArea,QWidget,QHBoxLayout,QMenu,QMessageBox,QPushButton
class PinnedApps(QScrollArea):
 def __init__(self,parent,launch,changed):
  super().__init__(parent);self.launch=launch;self.changed=changed;self.path=Path.home()/'.config/laccaz/pinned-apps.json';self.paths=[]
  try:self.paths=list(dict.fromkeys(p for p in json.loads(self.path.read_text()) if isinstance(p,str) and Path(p).is_file()))
  except (OSError,ValueError,TypeError):pass
  self.canvas=QWidget();self.row=QHBoxLayout(self.canvas);self.row.setContentsMargins(0,0,0,0);self.row.setSpacing(2);self.setWidget(self.canvas);self.setFixedHeight(42);self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.setStyleSheet('QScrollArea{border:0;background:transparent} QWidget{background:transparent}');self.refresh()
 def contains(self,path):return str(Path(path).resolve()) in self.paths
 def save(self):
  self.path.parent.mkdir(parents=True,exist_ok=True);tmp=self.path.with_suffix('.tmp');tmp.write_text(json.dumps(self.paths,ensure_ascii=False));os.replace(tmp,self.path)
 def toggle(self,path):
  path=str(Path(path).resolve())
  if not path.endswith('.desktop') or not Path(path).is_file():return
  old=self.paths.copy()
  if path in self.paths:self.paths.remove(path)
  else:self.paths.append(path)
  try:self.save()
  except OSError as e:self.paths=old;QMessageBox.warning(self,'Закрепление',str(e));return
  self.refresh();self.changed()
 def refresh(self):
  while self.row.count():
   w=self.row.takeAt(0).widget()
   if w:w.deleteLater()
  for path in self.paths:
   c=configparser.ConfigParser(interpolation=None,strict=False)
   try:c.read(path);e=c['Desktop Entry'];name=e.get('Name[ru]',e.get('Name',Path(path).stem));icon=e.get('Icon','')
   except (OSError,KeyError,configparser.Error):continue
   b=QPushButton();b.setFixedSize(44,42);b.setToolTip(name);b.setAccessibleName(name);ico=QIcon(icon) if icon.startswith('/') else QIcon.fromTheme(icon)
   if ico.isNull():b.setText(name[:1])
   else:b.setIcon(ico);b.setIconSize(QSize(32,32))
   b.setStyleSheet('QPushButton{border:0;padding:0;background:transparent;border-radius:5px} QPushButton:hover{background:rgba(110,150,210,65)}');b.clicked.connect(lambda checked=False,p=path:self.launch('gio',['launch',p]));b.setContextMenuPolicy(Qt.CustomContextMenu);b.customContextMenuRequested.connect(lambda pos,p=path,w=b:self.context(w,pos,p));self.row.addWidget(b)
  self.canvas.adjustSize();self.setVisible(bool(self.paths));self.setFixedWidth(min(len(self.paths)*46,max(40,self.screen().geometry().width()-560)))
 def context(self,w,pos,path):
  m=QMenu(self);m.addAction('Открепить от панели',lambda:self.toggle(path));m.exec(w.mapToGlobal(pos))
 def wheelEvent(self,e):self.horizontalScrollBar().setValue(self.horizontalScrollBar().value()-e.angleDelta().y());e.accept()
