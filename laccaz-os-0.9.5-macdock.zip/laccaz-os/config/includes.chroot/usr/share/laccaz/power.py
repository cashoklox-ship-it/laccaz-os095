"""Single-tap power-off request through logind/systemctl; never uses sudo."""
import sys
from pathlib import Path
from PySide6.QtCore import QObject,QProcess,QTimer,Signal,QLockFile,QStandardPaths
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication,QMessageBox
from appearance import STYLE
class PowerRequest(QObject):
 done=Signal()
 def __init__(self):super().__init__();self.busy=False;self.process=QProcess(self);self.process.finished.connect(self.completed);self.process.errorOccurred.connect(self.failed)
 def request(self):
  if self.busy:return
  self.busy=True
  self.process.start('systemctl',['poweroff'])
 def completed(self,code,status):
  if not self.busy:return
  self.busy=False
  if code!=0:QMessageBox.warning(None,'Выключение','Система не разрешила выключение. Проверь активные задачи и системные разрешения.')
  self.done.emit()
 def failed(self,error):
  if error==QProcess.FailedToStart and self.busy:self.busy=False;QMessageBox.warning(None,'Выключение','Не удалось запустить системную команду выключения.');self.done.emit()
if __name__=='__main__':
 app=QApplication(sys.argv);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE);app.setWindowIcon(QIcon(str(Path(__file__).with_name('logo.svg'))))
 directory=Path(QStandardPaths.writableLocation(QStandardPaths.CacheLocation))/'laccaz';directory.mkdir(parents=True,exist_ok=True);lock=QLockFile(str(directory/'power.lock'))
 if not lock.tryLock(0):sys.exit(0)
 request=PowerRequest();request.done.connect(app.quit);QTimer.singleShot(0,request.request);sys.exit(app.exec())
