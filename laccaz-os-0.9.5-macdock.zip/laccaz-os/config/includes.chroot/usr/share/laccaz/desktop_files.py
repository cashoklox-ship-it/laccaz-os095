"""Desktop icons backed by the user's real XDG Desktop directory."""
from pathlib import Path
from PySide6.QtCore import Qt,QStandardPaths,QDir,QSize,QFile
from PySide6.QtWidgets import QListView,QFileSystemModel,QAbstractItemView,QMenu,QInputDialog,QMessageBox
from PySide6.QtGui import QDesktopServices
from PySide6.QtCore import QUrl

class DesktopFiles(QListView):
 def __init__(self,parent):
  super().__init__(parent)
  self.folder=Path(QStandardPaths.writableLocation(QStandardPaths.DesktopLocation) or str(Path.home()/'Desktop'));self.folder.mkdir(parents=True,exist_ok=True)
  self.fs=QFileSystemModel(self);self.fs.setReadOnly(False);self.fs.setFilter(QDir.AllEntries|QDir.NoDotAndDotDot)
  self.setModel(self.fs);self.setRootIndex(self.fs.setRootPath(str(self.folder)))
  self.setViewMode(QListView.IconMode);self.setIconSize(QSize(48,48));self.setGridSize(QSize(112,100));self.setResizeMode(QListView.Adjust);self.setMovement(QListView.Snap)
  self.setSelectionMode(QAbstractItemView.ExtendedSelection);self.setDragDropMode(QAbstractItemView.DragDrop);self.setDefaultDropAction(Qt.CopyAction);self.setAcceptDrops(True);self.setDropIndicatorShown(True)
  self.setEditTriggers(QAbstractItemView.EditKeyPressed);self.setContextMenuPolicy(Qt.CustomContextMenu);self.customContextMenuRequested.connect(self.menu)
  self.doubleClicked.connect(lambda i:QDesktopServices.openUrl(QUrl.fromLocalFile(self.fs.filePath(i))))
  self.setStyleSheet('QListView{background:transparent;border:0;color:white;} QListView::item{border-radius:8px;padding:4px;} QListView::item:selected{background:rgba(100,150,220,100);} QListView::item:hover{background:rgba(150,180,220,45);}')
 def create(self,directory=False):
  name,ok=QInputDialog.getText(self,'Создать папку' if directory else 'Создать файл','Название:')
  if not ok or not name:return
  if name in ('.','..') or '/' in name or '\x00' in name:QMessageBox.warning(self,'Название','Введи имя без /');return
  try:
   p=self.folder/name
   if directory:p.mkdir()
   else:
    with p.open('x'):pass
  except OSError as e:QMessageBox.warning(self,'Создание',str(e))
 def trash(self):
  for i in self.selectedIndexes():
   if i.column()!=0:continue
   p=self.fs.filePath(i)
   if not QFile.moveToTrash(p):QMessageBox.warning(self,'Корзина','Не удалось переместить в корзину: '+p)
 def keyPressEvent(self,e):
  if e.key()==Qt.Key_Delete:self.trash()
  else:super().keyPressEvent(e)
 def menu(self,pos):
  i=self.indexAt(pos);m=QMenu(self)
  m.addAction('Создать папку',lambda:self.create(True));m.addAction('Создать файл',self.create)
  m.addAction('Открыть папку рабочего стола',lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.folder))))
  if i.isValid():
   m.addSeparator();m.addAction('Открыть',lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(self.fs.filePath(i))));m.addAction('Переименовать',lambda:self.edit(i));m.addAction('В корзину',self.trash)
  m.exec(self.mapToGlobal(pos))
