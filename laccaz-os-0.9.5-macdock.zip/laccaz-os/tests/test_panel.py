"""Task panel parsing and real Qt click events. No system windows are changed."""
import sys
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication,QPushButton
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from shell import Shell
from appearance import STYLE
app=QApplication([]);app.setStyleSheet(STYLE);s=Shell(preview=True);s.position_panel();app.processEvents()
wid=int(s.root.winId());rows=f'{wid:#010x} 0 shell.Laccaz host Own desktop\n0x12345601 0 editor.Editor host Editor\n0x12345602 1 notes.Notes host Notes\n0x12345603 -1 wallpaper.Desktop host Background\nmalformed\n'
s.update_tasks(rows);app.processEvents();assert s.task_ids==[('0x12345601','Editor'),('0x12345602','Notes')]
button=s.taskrow.itemAt(0).widget()
with patch('shell.start',return_value=True) as launch:QTest.mouseClick(button,Qt.LeftButton);launch.assert_called_once_with('wmctrl',['-ia','0x12345601'])
s.update_tasks('0x12345602 1 notes.Notes host Notes — Updated\n');app.processEvents();assert len(s.task_ids)==1 and s.task_ids[0][1]=='Notes — Updated'
s.update_tasks('0x12345604 0 firefox.Firefox host Mozilla Firefox\n');assert s.task_ids==[];assert s.pin_windows['browser']==['0x12345604']
with patch('shell.start',return_value=True) as launch:s.open_pin('browser',lambda:None);launch.assert_called_once_with('wmctrl',['-ia','0x12345604'])
s.update_tasks('');assert s.task_ids==[] and not s.pin_windows
s.cleanup_tasks();s.panel.close();s.root.close();s.bar.close();print('PASS panel excludes own/background windows, switches on click, updates titles and removes closed windows')
