"""Overlay policy and real Qt paint checks; no user windows or shutdown."""
import os,sys
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from PySide6.QtCore import Qt
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from shell import Shell
from appearance import STYLE
app=QApplication([]);app.setStyleSheet(STYLE);s=Shell(preview=True);app.processEvents()
with patch.dict(os.environ,{'DISPLAY':':test'}),patch('shell.start',return_value=True) as launch:
 s.properties();calls=[c.args[1] for c in launch.call_args_list]
 panel=[c for c in calls if str(int(s.panel.winId())) in c]
 assert any('_NET_WM_STRUT_PARTIAL' in c and c[-1]==', '.join(['0']*12) for c in panel)
 assert any('_NET_WM_STRUT' in c and c[-1]=='0, 0, 0, 0' for c in panel)
 assert any('_NET_WM_STRUT_PARTIAL' in c and c[-1].startswith('0, 0, 32, 0') for c in calls)
assert s.panel.windowFlags()&Qt.WindowStaysOnTopHint
assert s.panel.testAttribute(Qt.WA_TranslucentBackground)
assert s.panel.grab().toImage().pixelColor(12,28).alpha()>200
assert s.panel.height()==56
s.cleanup_tasks();print('PASS no bottom workarea reservation (both EWMH properties), upper bar retained, overlay flags, contrasting dock backing')
