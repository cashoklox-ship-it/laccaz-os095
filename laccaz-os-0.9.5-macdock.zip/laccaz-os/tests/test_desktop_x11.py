"""Run under a real X11 server and Openbox. No user desktop or network changes."""
import sys,subprocess
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication,QWidget
from PySide6.QtCore import Qt,QPoint
from PySide6.QtTest import QTest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from shell import Shell
from appearance import STYLE
app=QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE);s=Shell(preview=True);s.properties();QTest.qWait(400)
def command(args):return subprocess.check_output(args,text=True).strip()
def click(x,y):subprocess.run(['xdotool','mousemove',str(x),str(y),'click','1'],check=True);QTest.qWait(150)
# Empty desktop: physical pointer location must resolve to dock, even before other windows exist.
center=s.panel.mapToGlobal(s.panel.rect().center());subprocess.run(['xdotool','mousemove',str(center.x()),str(center.y())],check=True)
location=command(['xdotool','getmouselocation','--shell']);hit=int(location.split('WINDOW=')[1]);tree=command(['xwininfo','-id',str(hit),'-tree']);assert hit==int(s.panel.winId()) or hex(int(s.panel.winId())) in tree,(location,tree)
assert '_NET_WM_WINDOW_TYPE_DOCK' in command(['xprop','-id',str(int(s.panel.winId())),'_NET_WM_WINDOW_TYPE'])
assert '_NET_WM_WINDOW_TYPE_DESKTOP' in command(['xprop','-id',str(int(s.root.winId())),'_NET_WM_WINDOW_TYPE'])
# Launch button is clickable without another app. Discovery fixture is only for deterministic grid content.
button=s.pins[0][1];p=button.mapToGlobal(button.rect().center());click(p.x(),p.y());assert s.launcher.isVisible()
click(18,150);assert not s.launcher.isVisible(),'Application popup did not dismiss outside'
w=QWidget();w.setWindowTitle('Temporary app');w.resize(500,300);w.show();QTest.qWait(100);w.close();QTest.qWait(100);s.update_tasks('')
subprocess.run(['xdotool','mousemove',str(center.x()),str(center.y())],check=True);location=command(['xdotool','getmouselocation','--shell']);hit=int(location.split('WINDOW=')[1]);tree=command(['xwininfo','-id',str(hit),'-tree']);assert hit==int(s.panel.winId()) or hex(int(s.panel.winId())) in tree,(location,tree)
s.controls();QTest.qWait(100);assert s.control_panel.isVisible();click(18,150);assert not s.control_panel.isVisible(),'Control popup did not dismiss outside'
s.controls();QTest.qWait(60);QTest.keyClick(s.control_panel,Qt.Key_Escape);assert not s.control_panel.isVisible()
print('PASS native X11/Openbox empty-desktop dock hit testing, app button, dock after last app closes, popup outside-click and Escape dismissal')
s.show('apps');QTest.qWait(100);app.primaryScreen().grabWindow(0).save(str(r/'previews/desktop-apps-09.png'));s.launcher.hide();s.controls();QTest.qWait(100);app.primaryScreen().grabWindow(0).save(str(r/'previews/desktop-controls-09.png'));s.control_panel.hide();s.cleanup_tasks()
